#!/bin/bash

# Bash script to install required development libraries

# Function to install packages
install_package() {
    echo "Installing $1..."
    sudo apt-get install -y $1
}

# List of packages to install
packages=(
    libssl-dev
    libsqlite3-dev
    libldap2-dev
    libcurl4-openssl-dev
    libxerces-c-dev
    libxml2-dev
)

# Loop through the list of packages and install them
for package in "${packages[@]}"; do
    install_package "$package"
done

echo "Installation complete."
