/*
Description : Sample code with no vulnerable unchecked return value.
*/
#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>

int main()
{
    int fd, bytes_size;
    char* input = (char*)calloc(100, sizeof(char));
    fd = open("foo.txt", O_RDONLY);
    if (fd < 0) {
        perror("r1");
        exit(1);
    }

    bytes_size = read(fd, input, 9); //source
    if (bytes_size < 9 || bytes_size==-1) { //return value of the read function is cheked for max size of the input read to avoid buffer overflow and if the read function was succesfull in reading by checking -1.
        printf("Input is too long!\n");
        free(input);
        return 1;
    }
    printf("called read(% d, input, 10). returned that"
           " %d bytes were read.\n",
           fd, bytes_size);
    printf("Those bytes are as follows: % s\n", input);
    free(input);
    return 0;
}
