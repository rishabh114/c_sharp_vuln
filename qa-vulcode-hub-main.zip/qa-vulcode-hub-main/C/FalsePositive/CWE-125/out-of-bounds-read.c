/*
Sample code with no out of bounds read vulnerability
*/
#include <stdio.h>

int main() {    
    int max_length = 20;
    char name[20];
    printf("Enter your name: ");
    fgets(name, max_length, stdin); //fgets reads n-1 variables based on the variables size
    name[strcspn(name, "\n")]='\0'; 
    /*strcspn gives max the nth variable if no character from 2nd string is found in string1, 
      hence due to usage of fgets, strcspn can return max 19 and min 0, 
      19th index will have null character which will be within the given bounds of the array*/
    printf("entered name: %s,", name); 
    return 0;
}