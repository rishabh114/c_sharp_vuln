#include <stdio.h>
#include <string.h>

int main() {
    char source[] = "Hello, world!";
    char destination[20]; // Make sure it's large enough to hold the copied string

    // Copy at most sizeof(destination) - 1 characters from source to destination
    strncpy(destination, source, sizeof(destination) - 1);
    
    // Ensure null termination
    destination[sizeof(destination) - 1] = '\0';

    // Print the copied string
    printf("Copied string: %s\n", destination);

    return 0;
}
