/*
Sample code for false positive cases of type: missing release of file descriptor.
*/
#include <stdio.h>
#include <string.h>

int main(int argc, char **argv) {
    char buffer[100];
    if (argc != 2) {
        printf("Usage: %s <filename>\n", argv[0]);
        return 1;
    }

    char *userProvidedFilename = argv[1]; // Source
    loadFile(userProvidedFilename);

    FILE *file = fopen(userProvidedFilename, "r");//sink
    
    if (file != NULL) {
        while (fgets(buffer, sizeof(buffer), file) != NULL) {
            printf("%s", buffer);
        }
        fclose(file);
    } else {
        printf("File not found.\n");
    }
    return 0;
}