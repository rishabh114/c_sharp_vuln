#include <stdlib.h>
#define SIZE 16
int main(){
    char* ptr = (char*)malloc (SIZE);   //source
    if(ptr == NULL) {   //checks for memory allocation, if it returns null
        return 1;
    }
    if (0) {    //Always False
        free(ptr);  //this statement will never be executed
    }
    else {
          free(ptr);  //ptr freed here
    }
    return 0;
}
