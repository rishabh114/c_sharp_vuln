/*
Sample code for false positive cases of type: double free in function other than main
*/

#include <stdio.h>
#include <stdlib.h>
void double_free_func ( int* ptr , int a, int b) {
     int val = 0;
     if (! ptr) return;
     if(a) {
         *ptr+= 2;
     } else {
         val=*ptr ;
         free(ptr) ; // executed if a is false
     }
     if(b) {
         val += 5;
     } else if(!a) { // executed if a is false
         val += *ptr ;
     }
     if(a) free(ptr) ;  // executed if a is true
     printf ("val = %i\n", val) ;
     }

int main () {
     /* Unsafe function call */
     int *p;
     p = (int *) malloc(sizeof ( int));
        if(p == NULL) { //checks for memory allocation, if it is returns null
            return 1;
        }     
     double_free_func(p ,0,0) ;  
     return 0;
}
