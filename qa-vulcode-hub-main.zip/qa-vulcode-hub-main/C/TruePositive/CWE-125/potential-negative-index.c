/*
Sample code for vulnerable type: Potential Negative Number Used as Index
CWE : CWE-125
Description : snprintf function can return a negative value is used as an index. A negative array index can lead to reading or writing outside the bounds of the array
*/


#include <stdio.h>

int main() {
    int array[] = {1, 2, 3};
    int index = 0;

    char buffer[50];
    char* s = "somevalue";

    printf("Writing %s onto buffer"
           " with capacity 6",
           s);
    int length = snprintf(buffer, 6, "%s\n", s); //Source

    // Accessing the array 'array' instead of 'myArray'
    int value = array[length]; //Sink

    printf("Value at index %d is: %d\n", length, value);

    return 0;
}

