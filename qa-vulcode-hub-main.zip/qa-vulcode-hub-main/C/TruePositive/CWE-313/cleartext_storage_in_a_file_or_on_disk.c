/*
Sample code for vulnerable type: Cleartext Storage in a File or on Disk
CWE : CWE-313
Description : Cerdentials are stored in cleartext in a file
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_USERNAME_LENGTH 50
#define MAX_PASSWORD_LENGTH 50

#define admin_username admin
#define admin_password zsckaue@193

int validateCredentials(const char *username, const char *password) {
    char file_username[MAX_USERNAME_LENGTH];
    char file_password[MAX_PASSWORD_LENGTH];
    
    // Open the file in read mode
    FILE *file = fopen("credentials.txt", "r");
    if (file == NULL) {
        printf("Error opening file!\n");
        return 0; // File opening failed
    }
    
    // Read username and password from the file
    while (fscanf(file, "Username: %s\nPassword: %s\n", file_username, file_password) == 2) {
        // Check if the username and password match
        if (strcmp(username, file_username) == 0 && strcmp(password, file_password) == 0) {
            fclose(file);
            return 1; // Credentials match
        }
    }
    
    fclose(file);
    return 0; // Credentials not found or do not match
}

int signup() {
    char username[MAX_USERNAME_LENGTH];
    char password[MAX_PASSWORD_LENGTH];
    
    // Get username from the user
    printf("Enter username: ");
    scanf("%s", username);
    
    // Get password from the user
    printf("Enter password: ");
    scanf("%s", password); //source
    
    // Open the file in append mode
    FILE *file = fopen("credentials.txt", "a");
    if (file == NULL) {
        printf("Error opening file!\n");
        return 1;
    }
    
    // Write username and password to the file
    fprintf(file, "Username: %s\nPassword: %s\n", username, password); //sink
    
    // Close the file
    fclose(file);
    
    printf("Credentials have been saved to credentials.txt\n");
    
    return 0;
}

int login() {
        char username[MAX_USERNAME_LENGTH];
    char password[MAX_PASSWORD_LENGTH];
    
    // Get username from the user
    printf("Enter username: ");
    scanf("%s", username);
    
    // Get password from the user
    printf("Enter password: ");
    scanf("%s", password);
    return validateCredentials(username, password);    
}

int main() {
    int login_status, a;
    while (1) {
        printf("to register enter 1, \nfor login enter 2");
        if (a==1){
            signup();
        }
        else if (a==2) {
            login_status = login();
        }
        else {
            printf("invalid input");
        }
        if (login_status) {
            show_data();
        }
    }
    return 0;
}