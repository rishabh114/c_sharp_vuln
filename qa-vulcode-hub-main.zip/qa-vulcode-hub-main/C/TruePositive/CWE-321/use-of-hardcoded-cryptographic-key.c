/*
Sample code for vulnerable type: Use of Hardcoded Cryptographic Key
CWE : CWE-321
Description : The cryptographic key is hardcoded directly into the source code. This is an insecure practice because anyone with access to the source code can easily extract the key.
*/
#include <stdio.h>
#include <string.h>
#include <openssl/evp.h>
#include <openssl/aes.h>

int main() {
    // Hardcoded cryptographic key (insecure practice)
    unsigned char encryption_key[AES_BLOCK_SIZE] = {0x01, 0x23, 0x45, 0x67, 0x89, 0xab, 0xcd, 0xef,
                                                    0xfe, 0xdc, 0xba, 0x98, 0x76, 0x54, 0x32, 0x10}; //Source

    unsigned char plaintext[] = "Sensitive data";
    unsigned char ciphertext[AES_BLOCK_SIZE];

    AES_KEY enc_key;
    AES_set_encrypt_key(encryption_key, 128, &enc_key);// Sink

    AES_encrypt(plaintext, ciphertext, &enc_key);

    printf("Encrypted data: ");
    for (int i = 0; i < AES_BLOCK_SIZE; i++) {
        printf("%02x ", ciphertext[i]);
    }
    printf("\n");

    return 0;
}

