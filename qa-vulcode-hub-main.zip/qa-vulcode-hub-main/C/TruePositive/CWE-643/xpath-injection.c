/*
Sample code for vulnerable type: XPath Injection
CWE : CWE-643
Description : The user-provided searchQuery is directly used in the XPath query without proper validation. An attacker can exploit this by providing a malicious searchQuery that alters the query's behavior, leading to XPath injection.
*/
#include <stdio.h>
#include <libxml/parser.h>
#include <libxml/xpath.h>

int main(int argc, char **argv) {
    if (argc != 2) {
        printf("Usage: %s <search_query>\n", argv[0]);
        return 1;
    }

    char *searchQuery = argv[1];//Source

    xmlDocPtr doc;
    xmlXPathContextPtr xpathCtx;
    xmlXPathObjectPtr xpathObj;

    // Load an XML document
    doc = xmlParseFile("data.xml");

    if (doc == NULL) {
        printf("Failed to parse the XML document.\n");
        return 1;
    }

    // Create an XPath context
    xpathCtx = xmlXPathNewContext(doc);

    // Construct the XPath query
    char xpathExpression[100];
    snprintf(xpathExpression, sizeof(xpathExpression), "/data/record[@name='%s']", searchQuery);

    // User input is directly used in the XPath query
    xpathObj = xmlXPathEvalExpression((xmlChar *)xpathExpression, xpathCtx);//Sink

    if (xpathObj == NULL) {
        printf("XPath query evaluation failed.\n");
        return 1;
    }

    xmlXPathFreeObject(xpathObj);
    xmlXPathFreeContext(xpathCtx);
    xmlFreeDoc(doc);
    
    return 0;
}


