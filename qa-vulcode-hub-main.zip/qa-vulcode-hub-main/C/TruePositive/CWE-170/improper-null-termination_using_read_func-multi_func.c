/*
Sample code for vulnerable type: Improper Null Termination
CWE : CWE-170
Description : The code above will behave correctly if the data read from foo.txt is null terminated on disk as expected. 
But if an attacker is able to modify this input so that it does not contain the expected NULL character, the call to strcpy() will continue copying from memory until it encounters an arbitrary NULL character. 
This will likely overflow the destination buffer and, if the attacker can control the contents of memory immediately following inputbuf, can leave the application susceptible to a buffer overflow attack.
*/
#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

void perform_strcpy(char dest[], char* input) {
    strcpy(dest, input); //sink
    printf("Those bytes are as follows: %s\n", input);
}

int main() {
    int fd;
    char* input = (char*)calloc(100, sizeof(char));
    char var[10];  // Change var to an array of characters instead of an array of pointers

    fd = open("foo.txt", O_RDONLY);
    if (fd < 0) {
        perror("r1");
        exit(1);
    }

    int bytes_size = read(fd, input, 9); //source
    if (bytes_size < 9 || bytes_size == -1) {
        printf("Input is too long!\n");
        free(input);
        exit(1);
    }
    printf("called read(%d, input, 10). returned that %d bytes were read.\n", fd, bytes_size);

    // Sink operation
    perform_strcpy(var, input);

    free(input);
    return 0;
}
