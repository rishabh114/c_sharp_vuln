/*
Sample code for vulnerable type: Improper Null Termination
CWE : CWE-170
Description : readlink() does not append a NULL byte to buf. 
Readlink() will stop copying characters once the maximum size of buf has been reached to avoid overflowing the buffer, this will leave the value buf not NULL terminated.
Here the use of printf and strlen will continue traversing memory until it encounters a NULL character. Hence, this is case for improper null termination
*/
#include <stdio.h>
#include <unistd.h>

int main()
{
    int bufsize = 1000, len, bytes_read;
    char *buf;
    const char *linkPath = "/path/to/symlink";
    
    buf = (char *)malloc(bufsize);
    if (buf==NULL) {
        return 1;
    }
    bytes_read = readlink(linkPath, buf, bufsize-1); //source
    if (bytes_read==-1) {
        free(buf);
        return 1;
    }
    len = strlen(buf); //sink
    printf("Symbolic link target: %s, length: %d\n", buf, len); //sink
    free(buf);
    return 0;
}
