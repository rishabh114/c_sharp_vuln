/*
Sample code for vulnerable type: Improper Null Termination
CWE : CWE-170
Description : Here the buffer memory is allocated based on the string length if the user input.
Here the null terminator will not be considered which would result in possibility of Improper Null termination
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {
    char *userInput;

    printf("Enter a string: ");
    scanf("%s", userInput);

    // Vulnerable code: Using strlen to determine the size without considering the null terminator
    char *buffer = (char *)malloc(strlen(userInput));

    if (buffer == NULL) {
        perror("Memory allocation failed");
        return 1;
    }

    // Vulnerable code: Copying the string without considering the null terminator
    strcpy(buffer, userInput);  //source

    // Use the buffer
    printf("Buffer: %s\n", buffer); //sink

    // Free allocated memory
    free(buffer);

    return 0;
}

