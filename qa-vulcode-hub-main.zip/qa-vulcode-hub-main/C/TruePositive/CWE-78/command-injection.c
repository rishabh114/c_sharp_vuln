/*
Sample code for vulnerable type: Command Injection
CWE : CWE-78
Description : An attacker could provide input like "; rm -rf /" to the program, which would execute the provided command (rm -rf /) after the original command execution, potentially leading to data loss and system damage.
*/
#include <stdio.h>
#include <stdlib.h>

int main() {
    char command[100];
    printf("Enter a command to run: ");
    gets(command);  // Source
    system(command);// Sink

    return 0;
}

