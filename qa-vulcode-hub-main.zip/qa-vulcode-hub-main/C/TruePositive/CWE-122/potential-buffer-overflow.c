/*
Sample code for vulnerable type: Potential buffer overflow from usage of unsafe function
CWE : CWE-122
Description : Using gets can lead to buffer overflow vulnerabilities, if user input is able to flow into this function without the length of the input being checked. User can use fgets instead.
*/

#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>

int main() {
    char filename[100];
    printf("Enter a filename: ");
    gets(filename);  // source and sink, use fgets() instead
    int fd = open(filename, O_RDONLY);

    if (fd == -1) {
        perror("Error opening file");
        return 1;
    } else {
        printf("File opened successfully.\n");
        close(fd);
    }

    return 0;
}
