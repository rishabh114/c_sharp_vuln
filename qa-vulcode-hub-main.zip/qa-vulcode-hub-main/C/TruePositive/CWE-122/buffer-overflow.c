/*
Sample code for vulnerable type: Buffer Overflow
CWE : CWE-122
Description : Unchecked input from a command line argument flows into strcpy, where it is used to manipulate a string. This may result in a buffer overflow vulnerability.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <curl/curl.h>

int main(int argc, char **argv) {
  CURL *curl;
  CURLcode res;
  char url[100];//source

  if (argc != 2) {
    fprintf(stderr, "Usage: %s <url>\n", argv[0]);
    exit(1);
  }

  strcpy(url, argv[1]);//sink

  curl = curl_easy_init();
  if (curl == NULL) {
    fprintf(stderr, "Could not initialize cURL.\n");
    exit(1);
  }

  curl_easy_setopt(curl, CURLOPT_URL, url);
  res = curl_easy_perform(curl);

  if (res != CURLE_OK) {
    fprintf(stderr, "cURL error: %s\n", curl_easy_strerror(res));
    exit(1);
  }

  curl_easy_cleanup(curl);

  return 0;
}
