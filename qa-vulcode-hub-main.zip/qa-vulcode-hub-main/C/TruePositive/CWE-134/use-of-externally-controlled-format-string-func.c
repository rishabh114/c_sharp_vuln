/*
Sample code for vulnerable type: Use of Externally-Controlled Format String
CWE : CWE-134
Description : The contents of argv[1] are not properly validated or sanitized. This is a potential source of untrusted data, which can be controlled by a user or an external entity.
if the attacker passes %p as the string argument, then the function will print the memory addresses, potentially leaking sensitive information about the program's memory layout.
*/
#include <stdio.h>
#include <string.h>

void printWrapper(char *string) {
    printf(string);//sink
}

int main(int argc, char **argv) {
    char buf[5012];
    memcpy(buf, argv[1], 5012);//source
    printWrapper(argv[1]);
    return 0;
}

