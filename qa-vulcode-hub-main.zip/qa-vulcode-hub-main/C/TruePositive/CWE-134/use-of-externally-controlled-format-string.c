/*
Sample code for vulnerable type: Use of Externally-Controlled Format String
CWE : CWE-134
Description : The snprintf function is used to format the input from argv[1] into the buffer without any proper sanitation or validation. An attacker can providing a malicious argument to exploit the format string vulnerability.
Attackers could leverage format specifiers like %s to print arbitrary memory contents, potentially disclosing sensitive data.
*/

#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {
    char buffer[100];
    snprintf(buffer, sizeof(buffer), argv[1]); //Source (Unsafe usage of argv[1])

    printf("Formatted output: %s\n", buffer); //sink
    return 0;
}

