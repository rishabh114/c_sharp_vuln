/*
Sample code for vulnerable type: Path Traversal
CWE : CWE-23
Description : Here loadFile function load and display the contents of a file based on the provided filename. It does not properly sanitize the user-provided filename. An attacker can exploit this by providing a filename like "../../../../../etc/passwd", which could lead to reading sensitive system files outside the intended directory.
*/
#include <stdio.h>
#include <string.h>

void loadFile(char *filename) {
    char buffer[100];
    FILE *file = fopen(filename, "r");//sink
    
    if (file != NULL) {
        while (fgets(buffer, sizeof(buffer), file) != NULL) {
            printf("%s", buffer);
        }
        fclose(file);
    } else {
        printf("File not found.\n");
    }
}

int main(int argc, char **argv) {
    if (argc != 2) {
        printf("Usage: %s <filename>\n", argv[0]);
        return 1;
    }

    char *userProvidedFilename = argv[1]; // Source
    loadFile(userProvidedFilename);

    return 0;
}

