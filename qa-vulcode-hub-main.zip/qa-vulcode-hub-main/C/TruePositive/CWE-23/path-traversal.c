/*
Sample code for vulnerable type: Path Traversal
CWE : CWE-23
Description : Here the contents of a file will be read and displayed based on the provided filename. 
It does not properly sanitize the user-provided filename. 
An attacker can exploit this by providing a filename like "../../../../../etc/passwd", which could lead to reading sensitive system files outside the intended directory.
*/
#include <stdio.h>
#include <string.h>

int main(int argc, char **argv) {
    char buffer[100];
    if (argc != 2) {
        printf("Usage: %s <filename>\n", argv[0]);
        return 1;
    }

    char *userProvidedFilename = argv[1]; // Source
    loadFile(userProvidedFilename);

    FILE *file = fopen(userProvidedFilename, "r");//sink
    
    if (file != NULL) {
        while (fgets(buffer, sizeof(buffer), file) != NULL) {
            printf("%s", buffer);
        }
        fclose(file);
    } else {
        printf("File not found.\n");
    }
    return 0;
}

