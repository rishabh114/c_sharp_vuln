/*
Sample code for vulnerable type: Use After Free
CWE : CWE-416
Description : The below-provided code, ptr is used after it may already have been freed.
*/

#include <stdio.h>
#include <stdlib.h>
void use_after_free_func ( int* ptr , int a, int b) {
     int val = 0;
     if (! ptr) return;
     if(a) {
         *ptr+= 2;
     } else {
         val=*ptr ; //Use of null pointer detected : ptr
         free(ptr) ;
     }
     if(b) {
         val += 5;
     } else {
         val += *ptr ;//Sink use after free detected : ptr
     }
     if(a) free(ptr) ;
     printf ("val = %i\n", val) ;
     }

int main () {
     /* Unsafe function call */
     use_after_free_func(malloc(sizeof ( int)),0,0) ;//source
     return 0;
}
