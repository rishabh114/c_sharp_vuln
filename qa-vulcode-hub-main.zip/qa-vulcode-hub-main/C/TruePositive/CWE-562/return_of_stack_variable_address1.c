#include <stdio.h>
#include <string.h>

// Pattern 1: Returning the address of a local variable directly
char* getName1() {
    char name[100];
    strcpy(name, "John Doe");
    return name; // Vulnerability: Returning the address of a local variable directly
}

// Pattern 2: Returning the address of a local variable through a pointer
char* getName2() {
    char* name = (char*)malloc(100 * sizeof(char)); // Dynamically allocating memory
    strcpy(name, "Jane Smith");
    return name; // Vulnerability: Returning the address of dynamically allocated memory
}

int main() {
    char last_name[20];

    // Pattern 1: Using strcpy without checking bounds
    strcpy(last_name, getName1()); // Sink: Copying data from the returned address to 'last_name'
    printf("Pattern 1 - Last name: %s\n", last_name);

    // Pattern 2: Using strcpy with dynamically allocated memory
    char* ptr = getName2(); // Assigning the returned address to a pointer
    strcpy(last_name, ptr); // Sink: Copying data from the returned address to 'last_name'
    printf("Pattern 2 - Last name: %s\n", last_name);

    // Freeing dynamically allocated memory
    free(ptr);

    return 0;
}

