/*
Sample code for vulnerable type: Return of Stack Variable Address
CWE : CWE-562
Description : function getName returns stack variable "name", which will cause unintended program behavior, typically in the form of a crash.
*/



#include <stdio.h>
#include <string.h>

// Source function: Vulnerability - Returning the address of a local variable directly
char* getName1() {
    char name[100];
    strcpy(name, "John Doe");
    return name; // Source of vulnerability
}

// Sink function
void processName(const char* name) {
    // Sink code: Using the returned value from getName1() without proper handling
    printf("Hello, %s\n", name);
}

int main() {
    char* name = getName1(); // Source function call
    processName(name); // Sink function call

    return 0;
}
