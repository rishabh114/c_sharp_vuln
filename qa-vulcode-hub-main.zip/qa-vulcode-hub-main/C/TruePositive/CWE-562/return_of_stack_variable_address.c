/*
Sample code for vulnerable type: Return of Stack Variable Address
CWE : CWE-562
Description : function getName returns stack variable "name", which will cause unintended program behavior, typically in the form of a crash.
*/
#include <stdio.h>
#include <string.h>

char* getName() {
    char name[100];
    fillInName(name);
    return name; //source
}
int main() {
    char last_name[20];
    strcpy(last_name, getName()); //sink
    printf("Last name: %s\n", last_name);    
    return 0;
}
