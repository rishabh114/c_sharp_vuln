/*
Sample code for vulnerable type: Double free
CWE : CWE-415
Description : The below-provided code, Potential double call to free. ptr may have already been freed.
*/

#include <stdio.h>
#include <stdlib.h>
void double_free_func ( int* ptr , int a, int b) {
     int val = 0;
     if (! ptr) return;
     if(a) {
         *ptr+= 2;
     } else {
         val=*ptr ;
         free(ptr) ;
     }
     if(b) {
         val += 5;
     } else {
         val += *ptr ;
     }
     free(ptr) ; //sink
     printf ("val = %i\n", val) ;
     }

int main () {
     /* Unsafe function call */
    double_free_func(malloc(sizeof ( int)),0,0) ;  //source
    return 0;
}
