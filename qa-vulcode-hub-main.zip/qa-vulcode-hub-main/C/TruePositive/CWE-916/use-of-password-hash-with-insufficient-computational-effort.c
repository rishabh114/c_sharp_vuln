/*
Sample code for vulnerable type: Use of Password Hash With Insufficient Computational Effort
CWE : CWE-916
Description : In this example, MD5 is used for password hashing, which is known to be insecure for password storage due to its susceptibility to collision attacks and fast computation. 
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <openssl/md5.h>

#define PASSWORD_MAX_LENGTH 256
#define HASH_LENGTH MD5_DIGEST_LENGTH

void hash_password(const char *password, char *hashed_password) {
    MD5_CTX md5;
    MD5_Init(&md5); //source => usage of MD5 for password hash
    MD5_Update(&md5, password, strlen(password));
    MD5_Final((unsigned char *)hashed_password, &md5);
}

int main() {
    char password[PASSWORD_MAX_LENGTH];
    char hashed_password[HASH_LENGTH];

    printf("Enter password: ");
    fgets(password, PASSWORD_MAX_LENGTH, stdin);
    printf("entered password: %s", password);
    password[strcspn(password, "\n")] = '\0';  // To Remove newline character from input

    hash_password(password, hashed_password);

    printf("Password: %s\n", password); //sink => usage of the password
    printf("Hashed Password (MD5): ");
    for (int i = 0; i < HASH_LENGTH; i++) {
        printf("%02x", (unsigned char)hashed_password[i]);
    }
    printf("\n");

    return 0;
}
