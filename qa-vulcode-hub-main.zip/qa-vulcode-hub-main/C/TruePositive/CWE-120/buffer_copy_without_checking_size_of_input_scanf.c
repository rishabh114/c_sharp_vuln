/*
Sample code for vulnerable type: Buffer Copy without Checking Size of Input ('Classic Buffer Overflow')
CWE : CWE-120
Description : The product copies an input buffer to an output buffer without verifying that the size of the input buffer is less than the size of the output buffer, leading to a buffer overflow.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main() {
    char last_name[20];
    printf ("Enter your last name: ");
    scanf ("%s", last_name); //source
    printf("Last name : %s", last_name); //sink
    return 0;
}
