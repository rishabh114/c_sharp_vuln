/*
Sample code for vulnerable type: Buffer Copy without Checking Size of Input ('Classic Buffer Overflow')
CWE : CWE-120
Description : The product copies an input buffer to an output buffer without verifying that the size of the input buffer is less than the size of the output buffer, leading to a buffer overflow.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <curl/curl.h>

int main(int argc, char **argv) {
  CURL *curl;
  CURLcode res;
  char url[100];
  char *src;

  if (argc != 2) {
    fprintf(stderr, "Usage: %s <url>\n", argv[0]);
    exit(1);
  }
  src = argv[1]; 
  strcpy(url, argv[1]); //source

  curl = curl_easy_init();
  if (curl == NULL) {
    fprintf(stderr, "Could not initialize cURL.\n");
    exit(1);
  }

  curl_easy_setopt(curl, CURLOPT_URL, url); //sink
  res = curl_easy_perform(curl);

  if (res != CURLE_OK) {
    fprintf(stderr, "cURL error: %s\n", curl_easy_strerror(res));
    exit(1);
  }

  curl_easy_cleanup(curl);

  return 0;
}
