#include <iostream>
#include <xercesc/parsers/XercesDOMParser.hpp>
#include <xercesc/util/PlatformUtils.hpp>

void test(const char* data) {
    xercesc::XercesDOMParser* parser = new xercesc::XercesDOMParser();

    // BAD (parser is not correctly configured, may expand external entity references)
    parser->parse(data);

    // GOOD
    //parser->setDisableDefaultEntityResolution(true);
    //parser->parse(data);
}

void parseXmlData(const char* xmlData) {
    try {
        // Initialize Xerces-C++
        xercesc::XMLPlatformUtils::Initialize();

        // Create XercesDOMParser
        xercesc::XercesDOMParser* parser = new xercesc::XercesDOMParser();

        // Parse XML data
        parser->parse(xmlData); //sink

        // Get the document (unreachable in case of DoS)
        xercesc::DOMDocument* xmlDoc = parser->getDocument();

        // Cleanup
        delete parser;

        // Terminate Xerces-C++
        xercesc::XMLPlatformUtils::Terminate();
    } catch (const xercesc::XMLException& e) {
        std::cerr << "Exception: " << xercesc::XMLString::transcode(e.getMessage()) << std::endl;
    }
}

