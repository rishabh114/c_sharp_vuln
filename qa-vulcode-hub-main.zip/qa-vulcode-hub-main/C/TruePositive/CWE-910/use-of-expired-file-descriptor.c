/*
Sample code for vulnerable type: Use of Expired File Descriptor
CWE : CWE-910
Description : In this code, the program mistakenly attempts to call fgets on file which was already closed by fclose
*/

#include <stdio.h>

int main() {
    FILE *file;
    char buffer[100];
    //Open the file in read mode
    file = fopen("example.txt", "r");// Source
    if (file == NULL) {
        perror("Error opening file");
        return 1;
    }
    fclose(file);// Closing the file
    //Calling fgets after closing the file for reading the file content
    while (fgets(buffer, sizeof(buffer), file) != NULL) {//Sink
        char *newline = strchr(buffer, '\n');
        if (newline != NULL) {
            *newline = '\0';
        }

        printf("Line: %s\n", buffer);
    }

    return 0;
}

