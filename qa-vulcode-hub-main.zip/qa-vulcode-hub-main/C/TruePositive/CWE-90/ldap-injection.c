/*
Sample code for vulnerable type: LDAP Injection
CWE : CWE-90
Description : The user input (username) is directly embedded into the LDAP query filter, creating an LDAP injection vulnerability.
An attacker could provide input like *)(uid=*))(|(objectClass=* as the username, which would alter the filter to potentially retrieve unintended data or perform LDAP operations.
*/
#include <stdio.h>
#include <string.h>
#include <ldap.h>

int main() {
    LDAP *ld;
    int rc;
    const char *uri = "ldap://ldap.example.com";

    rc = ldap_initialize(&ld, uri);
    if (rc != LDAP_SUCCESS) {
        fprintf(stderr, "LDAP initialization failed: %s\n", ldap_err2string(rc));
        return 1;
    }

    char username[100];
    printf("Enter a username: ");
    gets(username);  //Source

    char filter[200];
    sprintf(filter, "(uid=%s)", username);//Sink

    rc = ldap_search_ext_s(ld, "dc=example,dc=com", LDAP_SCOPE_SUBTREE, filter, NULL, 0, NULL, NULL, NULL, LDAP_NO_LIMIT, NULL);//Sink
    if (rc != LDAP_SUCCESS) {
        fprintf(stderr, "LDAP search failed: %s\n", ldap_err2string(rc));
    } else {
        printf("Search successful.\n");
    }

    ldap_unbind_ext_s(ld, NULL, NULL);
    return 0;
}

