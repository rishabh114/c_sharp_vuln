/*
Sample code for vulnerable type: User Controlled Pointer
CWE : CWE-1285
Description : The programmer allows the user to specify which element in the list to select, however an attacker can provide an out-of-bounds offset, resulting in a buffer over-read (CWE-126).
*/

int main (int argc, char **argv) {
    char *items[] = {"boat", "car", "truck", "train"};
    int index;
    printf("Enter the index of item to be printed");
    scanf("%d", &index); //source
    printf("User selected %s\n", items[index-1]);  //sink
    return 0;
}