/*
Sample code for vulnerable type: User Controlled Pointer
CWE : CWE-1285
Description : The programmer allows the user to specify which element in the list to select, however an attacker can provide an out-of-bounds offset, resulting in a buffer over-read (CWE-126).
*/

#include <iostream>
 
int main() {
    int size = 10;
    int array[size];
 
    std::cout << "Enter the index: ";
    std::cin >> size;   //source
 
    // Potential vulnerability: Using 'size' as an array index without validation
    int value = array[size];    //sink
 
    std::cout << "Value at index " << size << " is: " << value << std::endl;
 
    return 0;
}