/*
Sample code for vulnerable type: Unchecked Return Value
CWE : CWE-252
Description : return value of read function is not validated and used further which could lead to vulnerabilities
*/
#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>

int main()
{
    int fd, bytes_size;
    char* input = (char*)calloc(100, sizeof(char));
    fd = open("foo.txt", O_RDONLY);
    if (fd < 0) {
        perror("r1");
        exit(1);
    }

    bytes_size = read(fd, input, 9); //source
    input[bytes_size] = 'a'; //sink
    printf("called read(% d, input, 10). returned that"
           " %d bytes were read.\n",
           fd, bytes_size);
    printf("Those bytes are as follows: % s\n", input);
    free(input);
    return 0;
}
