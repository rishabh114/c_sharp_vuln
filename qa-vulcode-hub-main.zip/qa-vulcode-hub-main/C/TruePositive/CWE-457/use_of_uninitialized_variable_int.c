/*
Sample code for vulnerable type: Use of Uninitialized Variable
CWE : CWE-457
Description : Uninitialized integer variable is used as index for an integer array, 
this variable could hold junk value resulting in program crash.
*/
#include <stdio.h>

int main() {
    int x, array[10], size; // source: uninitialized integer variable

    // uninitialized variable used as index
    array[x] = 0; //sink
    size = sizeof(array) / sizeof(array[0]);

    // Iterate through the array and print each element
    printf("Array of integers: ");
    for (int i = 0; i < size; i++) {
        printf("%d ", array[i]);
    }
    printf("The value of x is: %d\n", x);

    return 0;
}
