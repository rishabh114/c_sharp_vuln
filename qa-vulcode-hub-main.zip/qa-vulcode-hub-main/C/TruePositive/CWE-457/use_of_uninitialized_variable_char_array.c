/*
Sample code for vulnerable type: Use of Uninitialized Variable
CWE : CWE-457
Description : Uninitialized char array is used in print statement, 
this variable could point to a sensitive data as it holds an address and will print till it gets a null terminator.
*/
#include <stdio.h>

int main() {
    char array[10]; // source:
    printf("The value of array is: %s\n", array); // sink
    return 0;
}
