/*
Sample code for vulnerable type: An optimizing compiler may remove memset non-zero leaving data in memory
CWE : CWE-1330
Description : The memset function is used to set a block of memory to a specific value, and in this case, it's being used to clear the password array to all zeros. This can be a common practice to ensure sensitive data is cleared from memory.
*/

#include <string.h>

int main() {
    char password[16];
    strncpy(password, "mypass", sizeof(password));// Source
    memset(password, 0, sizeof(password));// Sink
    return 0;
}
