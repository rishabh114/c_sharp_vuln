/*
Sample code for vulnerable type: Use of Potentially Dangerous Function
CWE : CWE-676
Description : The strcpy function provides no way to limit the amount of data that is copied from source to destination, 
so without prior knowledge of the source it is impossible to use it safely.
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <curl/curl.h>

int main(int argc, char **argv) {
  CURL *curl;
  CURLcode res;
  char url[100];
  char *src;

  if (argc != 2) {
    fprintf(stderr, "Usage: %s <url>\n", argv[0]);
    exit(1);
  }
  src = argv[1]; //source
  strcpy(url, argv[1]); //sink

  curl = curl_easy_init();
  if (curl == NULL) {
    fprintf(stderr, "Could not initialize cURL.\n");
    exit(1);
  }

  curl_easy_setopt(curl, CURLOPT_URL, url);
  res = curl_easy_perform(curl);

  if (res != CURLE_OK) {
    fprintf(stderr, "cURL error: %s\n", curl_easy_strerror(res));
    exit(1);
  }

  curl_easy_cleanup(curl);

  return 0;
}
