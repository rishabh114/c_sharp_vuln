/*
Sample code for vulnerable type: Use of Potentially Dangerous Function
CWE : CWE-676
Description : The gets function provides no way to limit the amount of data that is read and stored, 
so without prior knowledge of the input it is impossible to use it safely with any size of buffer.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define BUFFERSIZE (1024)

int main() {
    char buffer[BUFFERSIZE];
    //source: here source will be the user input as the usage of gets function itself will be sink
    gets(buffer); //sink
    printf("Input was: '%s'\n", buffer);
    return 0;
}