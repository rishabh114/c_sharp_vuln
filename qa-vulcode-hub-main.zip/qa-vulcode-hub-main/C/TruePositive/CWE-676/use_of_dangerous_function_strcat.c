/*
Sample code for vulnerable type: Use of Potentially Dangerous Function
CWE : CWE-676
Description : The strcat function provides no way to limit the amount of data that is copied from source to destination, 
so without prior knowledge of the source it is impossible to use it safely.
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
    char dest[10];
    char *src;

    if (argc > 1) {
        src = argv[1]; // Source        
        strcat(dest, src); // Sink
        printf("Combined string: %s\n", dest);
    } else {
        printf("No string provided.\n");
    }

    return 0;
}
