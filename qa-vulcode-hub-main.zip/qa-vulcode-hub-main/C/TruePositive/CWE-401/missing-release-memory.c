/*
Sample code for vulnerable type: Missing Release of Memory after Effective Lifetime
CWE : CWE-401
Description : Memory allocated by malloc may be leaked if the control flow reaches this return. The allocated memory does not seem to be freed on all possible execution paths.

The source of data in this code is the strcpy function, which copies the string "This string is in the heap" into the dynamically allocated memory pointed to by ptr. The data originates from the code itself and is stored in the ptr variable.

The potential issue in this code is related to memory management, specifically regarding the potential misuse of memory allocation and deallocation. When err is true (non-zero), memory is allocated to ptr2 dynamically. However, this memory is not being used, and there's no free operation for ptr2. This can lead to a memory leak.
*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#define SIZE 64

int main (){
    int abrt=0;
    int err=1;
    char* ptr = (char*) malloc(SIZE*sizeof(char));
    strcpy(ptr,"This string is in the heap");//source
    if (err) {
        abrt = 1;
        free(ptr);
        char* ptr2 = (char*) malloc(2*sizeof(char));
    }
    if (abrt) {
        printf("operation aborted before commit. Pointer value is ptr: %s",ptr);//sink
    }
    return 0;
}
