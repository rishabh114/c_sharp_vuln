/*
Sample code for vulnerable type: Server-Side Request Forgery (SSRF)
CWE : CWE-918
Description : An attacker can potentially supply a URL that points to internal resources, such as localhost services, which could lead to an SSRF vulnerability. For example, an attacker might input http://localhost/private-resource to try accessing an internal service or file.
*/

#include <stdio.h>
#include <string.h>
#include <curl/curl.h>

size_t write_callback(void *contents, size_t size, size_t nmemb, void *userp) {
    size_t total_size = size * nmemb;
    fwrite(contents, 1, total_size, (FILE *)userp);
    return total_size;
}

int main() {
    CURL *curl;
    CURLcode res;

    char url[200];
    printf("Enter a URL to fetch: ");
    fgets(url, sizeof(url), stdin);//Source 

    // Remove newline character from the URL
    char *newline = strchr(url, '\n');
    if (newline != NULL) {
        *newline = '\0';
    }

    FILE *output = fopen("output.html", "wb");

    curl = curl_easy_init();
    if (curl) {
        curl_easy_setopt(curl, CURLOPT_URL, url); //Sink
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, write_callback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, output);

        res = curl_easy_perform(curl);

        if (res != CURLE_OK) {
            fprintf(stderr, "curl_easy_perform() failed: %s\n", curl_easy_strerror(res));
        }

        curl_easy_cleanup(curl);
        fclose(output);
    }

    return 0;
}

