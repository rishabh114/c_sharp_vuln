/*
Sample code for vulnerable type: Division By Zero
CWE : CWE-369
Description : The divisor in the division operator is zero, which may cause a division by zero to occur. Divisors should be checked to be non-zero before use.
*/

int divisor_func(){
    return 0;
}
int main()
{
    int x;
    int y=divisor_func();// source
    x=2/y;  // Sink
    printf("%d",x);
    return 0;
}
