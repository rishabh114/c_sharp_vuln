/*
Sample code for vulnerable type: Division By Zero
CWE : CWE-369
Description : The divisor in the division operator is zero, which may cause a division by zero to occur. Divisors should be checked to be non-zero before use.
*/

int main()
{
    int x;
    x=1/0;  //source and sink
    return 0;
}
