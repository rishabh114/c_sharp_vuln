/*
Sample code for vulnerable type: Integer Overflow or Wraparound
CWE : CWE-190
Description : This code will keep getting input till the bytesRec is less than INT_MAX, but as it is incremented based on the number of character inputs it receives, 
the bytesRec can be incremented above INT_MAX resulting in Integer overflow making it a negative number. this can result in infinite looping and memory crash as the text file will keep on getting appended.
*/
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

int getFromInput(char buf[]) {
    int i=0, bytesRec;
    char c;
    FILE *fptr;
    print("enter input string, enter 0 for exit");
    do {
        scanf("%c", &c);
        if (c!='0') {
            break;
        }
        buf[i]=c;
        i++;
    } while(1 && i!=999999);

    bytesRec = i;
    if (buf[i]!='\0')
    {
            buf[i]='\0';
    }
    fptr = fopen("filename.txt", "a");
    if (fptr==NULL) {
      printf("fptr is null");
      return 1;
    }
    while (i!=0) {
      i-=1;
      fprintf(fptr, "Some text : %d\n", i);
    }
    fclose(fptr);        
    return bytesRec;
}
int main() {    
    short int bytesRec = 0;
    char buf[1000000];
    while(bytesRec < INT_MAX) {  //sink
        bytesRec += getFromInput(buf); //source
    }
    return 0;
}