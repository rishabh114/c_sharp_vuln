/*
Sample code for vulnerable type: Inadequate Encryption Strength
CWE : CWE-326
Description : The cryptographic key is hardcoded with an AES-128 bit key, which may be considered inadequate for some security requirements.
*/

#include <stdio.h>
#include <string.h>
#include <openssl/evp.h>
#include <openssl/aes.h>

int main() {
    // Hardcoded cryptographic key with inadequate encryption strength (128 bits)
    unsigned char encryption_key[AES_BLOCK_SIZE] = {0x01, 0x23, 0x45, 0x67, 0x89, 0xab, 0xcd, 0xef,
                                                    0xfe, 0xdc, 0xba, 0x98, 0x76, 0x54, 0x32, 0x10};//Source

    unsigned char plaintext[] = "Sensitive data";
    unsigned char ciphertext[AES_BLOCK_SIZE];

    AES_KEY enc_key;
    AES_set_encrypt_key(encryption_key, 128, &enc_key);  //Sink  Using 128-bit key (inadequate for some applications)

    AES_encrypt(plaintext, ciphertext, &enc_key);

    printf("Encrypted data: ");
    for (int i = 0; i < AES_BLOCK_SIZE; i++) {
        printf("%02x ", ciphertext[i]);
    }
    printf("\n");

    return 0;
}

