/*
Sample code for vulnerable type: Anonymous LDAP binding allows a client to connect without logging in
CWE : CWE-287
Description : In this code, anonymous LDAP binding is performed by calling ldap_simple_bind_s without providing a username and password. This allows anyone to connect to the LDAP server without authentication.
*/
#include <stdio.h>
#include <ldap.h>

int main() {
    LDAP *ld;
    int rc;

    // Initialize an LDAP connection
    rc = ldap_initialize(&ld, "ldap://example.com");//Source
    if (rc != LDAP_SUCCESS) {
        fprintf(stderr, "ldap_initialize failed: %s\n", ldap_err2string(rc));
        return 1;
    }

    // Perform anonymous LDAP binding
    rc = ldap_simple_bind_s(ld, NULL, NULL);//Sink

    if (rc != LDAP_SUCCESS) {
        fprintf(stderr, "ldap_simple_bind_s failed: %s\n", ldap_err2string(rc));
        return 1;
    }

    ldap_unbind(ld);

    return 0;
}

