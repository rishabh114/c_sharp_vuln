/*
Sample code for vulnerable type: Unquoted Search Path or Element
CWE : CWE-428
*/

#include <stdio.h>
#include <stdlib.h>

int main() {
    char filename[100];

    printf("Enter filename: ");
    scanf("%s", filename); // source

    // Vulnerable execution of system without proper quoting
    system(filename); // sink //use of unquoted string filename

    return 0;
}

