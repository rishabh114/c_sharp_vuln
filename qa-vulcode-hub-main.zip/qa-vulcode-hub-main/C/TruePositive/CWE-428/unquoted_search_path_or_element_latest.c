#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

void bad() {
    char *args[] = {"/usr/bin/notepad", NULL};
    execvp(args[0], args);
}

void good() {
    char *args[] = {"/usr/bin/myapp", NULL};
    execvp(args[0], args);
}

int main() {
    bad();
    good();
    return 0;
}

