// BAD: lpApplicationName is null and path string is not surrounded by quotes
void bad() {
    std::wstring path = L"C:\\windows\\notepad.exe";
    CreateProcessW(
        0,  // lpApplicationName
        &path,  // lpCommandLine
        NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi
    );
}

// BAD: lpApplicationName is null and path string is not surrounded by quotes
void bad() {
    std::wstring path = L"C:\\windows\\notepad.exe";
    CreateProcessW(
        NULL,  // lpApplicationName
        &path,  // lpCommandLine
        NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi
    );
}

// GOOD
void good() {
    std::wstring path = L"\"C:\\Program Files\\MyApp\"";
    CreateProcessW(
        NULL,  // lpApplicationName
        &path,  // lpCommandLine
        NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi
    );
}

// UNKNOWN: do not detect
void unknown(std::wstring path) {
    CreateProcessW(
        NULL,  // lpApplicationName
        &path,  // lpCommandLine
        NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi
    );
}
