/*
Sample code for vulnerable type: SQL Injection
CWE : CWE-89
Description : An attacker could provide input like ' OR '1'='1 as the username, which would alter the query to always return all rows, potentially bypassing authentication.
*/
#include <stdio.h>
#include <string.h>
#include <sqlite3.h>

int main() {
    sqlite3 *db;
    char *errMessage = 0;
    int rc;

    rc = sqlite3_open("mydatabase.db", &db); // Open the database
    if (rc) {
        fprintf(stderr, "Can't open database: %s\n", sqlite3_errmsg(db));
        return(0);
    }

    char username[100];
    printf("Enter a username: ");
    gets(username);  // Source

    char query[200];
    sprintf(query, "SELECT * FROM users WHERE username='%s';", username);

    rc = sqlite3_exec(db, query, 0, 0, &errMessage);//sink
    if (rc != SQLITE_OK) {
        fprintf(stderr, "SQL error: %s\n", errMessage);
        sqlite3_free(errMessage);
    } else {
        printf("Query executed successfully.\n");
    }

    sqlite3_close(db); // Close the database
    return 0;
}

