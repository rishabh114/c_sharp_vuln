# Python
This Python Repo has Vulnerable Codes For Different Vulnerability , with source and sink in same function aswell as different functions.
Files ending with _SF.py having source and sink in same method wheras _DF.py having source and sink in different functions.




CWE Coverage
1. CWE - 1004
2. CWE - 20
3. CWE - 200
4. CWE - 209
5. CWE - 22
6. CWE - 23
7. CWE - 259
8. CWE - 280
9. CWE - 284
10. CWE - 287
11. CWE - 295
12. CWE - 310
13. CWE - 312
14. CWE - 319
15. CWE - 321
16. CWE - 326
17. CWE - 327
18. CWE - 329
19. CWE - 346
20. CWE - 352
21. CWE - 377
22. CWE - 400
23. CWE - 453
24. CWE - 489
25. CWE - 502
26. CWE - 601
27. CWE - 611
28. CWE - 614
29. CWE - 643
30. CWE - 732
31. CWE - 757
32. CWE - 78
33. CWE - 79
34. CWE - 89
35. CWE- 916
36. CWE - 918
37. CWE - 94
38. CWE - 942
39. CWE - 943


