function readData(buffer: Buffer, length: number): string {
    // Read data from the buffer without checking the length
    const data = buffer.slice(0, length).toString('utf8');
    return data;
}

// Example usage
const buffer = Buffer.from('Hello, World!', 'utf8');

// Try to read 20 characters from the buffer
const result = readData(buffer, 20);
console.log('Data read:', result);
