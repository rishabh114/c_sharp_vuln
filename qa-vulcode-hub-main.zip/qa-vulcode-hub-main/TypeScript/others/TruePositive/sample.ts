import jwt from 'jsonwebtoken';

const token = 'eyJhbGciOiAiSFMyNTYiLCAidHlwIjogIkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.0pY71QV7dtaJh8I3fU4rL36oZHZx8kqS2E-Ac2yYV6E';
//const secretKey = 'your_secret_key'; // Replace with your secret key

try {
  const decoded = jwt.verify(token);
  console.log(decoded);
} catch (error) {
  console.error('Invalid token:', error.message);
}
