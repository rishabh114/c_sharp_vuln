/*
Sample code for vulnerable type: Arbitrary File Write via Archive Extraction (Zip Slip)
CWE : CWE-22
Description :  The below  provided code is vulnerable to the "Arbitrary File Write via Archive Extraction" attack, also known as "Zip Slip." This vulnerability occurs when an application does not properly validate the paths of thefiles being extractedfrom an archive, allowing an attacker to create or overwrite files outside of the intended directory
*/

import * as fs from 'fs';
import * as unzipper from 'unzipper'; // Assuming you are using 'unzipper' package

fs.createReadStream('archive.zip')
  .pipe(unzipper.Parse()) // Source
  .on('entry', (entry: unzipper.Entry) => {
    const fileName = entry.path;
    // WARNING: This could write any file on the filesystem.
    entry.pipe(fs.createWriteStream(fileName)); //Sink
  });
