/*
Type of vulnerability : Command Injection
CWE : CWE-78
Discription : In this example, the executeCommand function is responsible for executing the command obtained from the user input. The handleRequest function retrieves the command from the request and then calls the executeCommand function.
*/

import { execSync } from 'child_process';
import { Request } from 'express';

function executeCommand(cmd) {
    execSync(cmd);
}

function handleRequest(req) {
    const cmd = req.query.cmd;
    executeCommand(cmd);
}

// Assuming you have a valid Express request object
const sampleRequest = {
    query: {
        cmd: 'ls -l' // Replace with a safe command
    }
};

// Call the function to handle the request
handleRequest(sampleRequest);
