/*
Sample Code for vulnerability Type: Use of Hardcoded Credentials

Hard-coding credentials is the software development practice of embedding authentication data — user IDs andpasswords — directly into the source code of a program or other executable object. This is as opposed to obtaining the credentials from external sources or generating them at runtime.

CWE: CWE-259 & CWE-798
*/


using System;

namespace UserAuthentication
{
    public class UserController
    {
        public string AuthenticateUser(string username, string password)
        {
            // Simplified authentication logic
            if (username == "admin" && password == "admin123")
            {
                return "Welcome, admin!";
            }
            else
            {
                return "Login failed";
            }
        }
    }

    public class MainApp
    {
        public static void Main(string[] args)
        {
            UserController userController = new UserController();
            string username = Console.ReadLine();
            string password = Console.ReadLine();

            string authenticationResult = userController.AuthenticateUser(username, password);
            Console.WriteLine(authenticationResult);
        }
    }
}
