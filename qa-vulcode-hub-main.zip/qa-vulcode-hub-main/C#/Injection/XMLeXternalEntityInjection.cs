/* 
Sample code for vulnerability XML External Entity (XXE) Injection (CWE-611)

Description : XML External Entity (XXE) Injection is a type of security vulnerability that occurs when an XML parser improperly processes external entities defined in the XML document. In this attack, an attacker can manipulate XML input to include references to external entities, which can lead to the disclosure of internal files, denial of service attacks, server-side request forgery, and more. By exploiting XXE vulnerabilities, attackers can access sensitive data, execute arbitrary code, and compromise the security of web applications and services that parse XML input without proper validation and protection measures in place. It's essential for developers to validate and sanitize XML input, disable external entity processing, and use secure parsing libraries to prevent XXE attacks.
*/

using System;
using System.Web;
using System.Web.UI;
using System.Xml;
using System.IO;

namespace vulnerable_xxe
{
	public class VulnerableHandler : System.Web.IHttpHandler
	{
		public virtual bool IsReusable {
			get {
				return false;
			}
		}

		public virtual void ProcessRequest (HttpContext context)
		{
			if (context.Request.RequestType != "POST") {
				context.Response.Write ("Needs to be a POST");
				return;
			}

			if (string.IsNullOrEmpty (context.Request ["XML"])) {
				context.Response.Write("Needs an XML Param");
				return;
			}

			byte[] xmlBytes = Convert.FromBase64String(context.Request["XML"]); //SOURCE

			XmlReaderSettings settings = new XmlReaderSettings();
			settings.ProhibitDtd = false;

			XmlDocument doc = new XmlDocument();
			doc.Load(XmlReader.Create(new MemoryStream(xmlBytes), settings)); //SINK

			context.Response.Write(doc.LastChild.OuterXml);
		}
	}
}

