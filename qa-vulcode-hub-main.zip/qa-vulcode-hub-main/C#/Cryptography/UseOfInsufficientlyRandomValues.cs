/*
Vulnerability Type : Use of Insufficiently Random Values
CWE : CWE-42
Description : When product generates predictable values in a context requiring unpredictability, it may be possible for an attacker to guess the next value that will be generated, and use this guess to impersonate another user or access sensitive information.
*/

using System;

class RandomKeyGenerator
{
    static void Main(string[] args)
    {
        string insecureKey = GenerateInsecureKey();
        
        // Using the insecure key for encryption or other security operations
        Console.WriteLine("Insecure Key: " + insecureKey);
    }

    static string GenerateInsecureKey()
    {
        Random random = new Random();
        int randomNumber = random.Next(100000, 999999); // Generate a random 6-digit number
        string insecureKey = "KEY_" + randomNumber.ToString();
        return insecureKey;
    }
}
